package com.czterysery.drone.drone;

/**
 * Created by tmax0 on 02.10.2017.
 */

public interface AsyncResponse {
    void showResult(Double output);
}
