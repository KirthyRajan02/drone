package com.czterysery.drone.drone;

public final class Parameters {
    public static final String WIFI_NAME = "MYESP32";
    public static final String WIFI_PASSWORD = "testpassword";
    public static final String HOST_ADDRESS = "192.168.4.1";
    public static final Integer PORT = 80;
}
